# Corre, Zeca! — projeto para gerar o APK

## Opção A: sem instalar nada (GitHub)
1. Crie um repositório no github.com e envie todos os arquivos desta pasta (inclusive a pasta .github).
2. Abra a aba **Actions**, espere o fluxo "Gerar APK" terminar (uns 5 minutos).
3. Entre na execução concluída e baixe o artefato **corre-zeca-apk**. Dentro está o app-debug.apk.
4. Passe o APK para o celular e instale (permita "fontes desconhecidas").

## Opção B: no seu computador (Node 18+, Java 17 e Android Studio)
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
No Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).

Para mudar o jogo, edite www/index.html e rode `npx cap sync android` de novo.
